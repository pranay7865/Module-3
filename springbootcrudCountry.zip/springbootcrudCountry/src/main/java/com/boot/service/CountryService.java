package com.boot.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.dao.CountryRepository;
import com.boot.entity.Country;

@Service
public class CountryService {

	//countryRepository is dependency of CountryService
	
	@Autowired
	private CountryRepository countryRepository;

	/*
	 * private List<Country> listOfCountry= new ArrayList<>(Arrays.asList(new
	 * Country("1", "India", "Delhi"), new Employee("2", "U.S.A",
	 * "Washington D.C."), new Employee("3", "U.K", "London"),
	 * new Employee("4", "U.A.E", "Abu Dhabi"), new Employee("5",
	 * "Russia", "Moscow")));
	 */
	public List<Country> getAll() {
		List<Country> list = new ArrayList<>();
		countryRepository.findAll().forEach(list::add);
		
		return list;
	}

	public Optional<Country> getCountry(String firstname) {
//		return listOfEmployee.stream().filter(s -> s.getFirstname().equals(firstname)).findFirst().get();
		return countryRepository.findById(firstname);
	}

	public Country addCountry(Country country) {
//		listOfCountry.add(country);
		return countryRepository.save(country);
	}

	public Country updateCountry(Country country, String firstname) {
		/*
		 * for (int i = 0; i < listOfCountry.size(); i++) { if
		 * (listOfCountry.get(i).getFirstname().equals(firstname)) {
		 * listOfCountry.set(i, country); } }
		 */
//		countryRepository.saveByFirstname(employee);

		return countryRepository.save(country);
		
	}

	public void deleteCountry(String id) {
//		for (int i = 0; i < listOfCountry.size(); i++) {
//			if (listOfCountry.get(i).getFirstname().equals(firstname))
//				listOfCountry.remove(i);
//		}
		countryRepository.deleteById(id);
	}
}
