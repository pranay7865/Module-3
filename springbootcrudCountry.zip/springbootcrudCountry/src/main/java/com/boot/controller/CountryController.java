package com.boot.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.boot.entity.Country;
import com.boot.service.CountryService;

@RestController
public class CountryController {

	@Autowired
	private CountryService countryService;

	@GetMapping("countries")
	public List<Country> getCountries() {
		return countryService.getAll();
	}

	@GetMapping(value = "/countries/{id}")
	public Optional<Country> getCountry(@PathVariable String id) {
		return countryService.getCountry(id);
	}

//	@RequestMapping(value = "/countries", method = RequestMethod.POST)
	@PostMapping("/countries")
	public ResponseEntity<Country> addCountry(@RequestBody Country country) {

		Country e = countryService.addCountry(country);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(e.getId());

		return ResponseEntity.created(location).build();

	}

	@PutMapping("/countries/{id}")
	public ResponseEntity<Country> updateCountry(@RequestBody Country country, @PathVariable String id) {
		Country e = countryService.updateCountry(country, id);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(e.getId());

		return ResponseEntity.created(location).build();

		// @formatter:on

	}

	@DeleteMapping("/countries/{id}")
	public void deleteCountry(@PathVariable String id) {
		countryService.deleteCountry(id);
	}
}
