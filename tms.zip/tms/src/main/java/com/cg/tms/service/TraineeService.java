package com.cg.tms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.bean.Trainee;
import com.cg.tms.dao.TraineeRepository;

@Service
public class TraineeService {

	@Autowired
	private TraineeRepository tRepo;

	public Trainee saveTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return tRepo.save(trainee);
	}
	
	public List<Trainee> getAll(){
		List<Trainee> list = null;
		tRepo.findAll().forEach(list::add);
		return list;
	}
	

	public void saveTrainees(List<Trainee> list) {
		// TODO Auto-generated method stub
		tRepo.saveAll(list);
	}

	public Optional<Trainee> getTrainee(Long id) {
		// TODO Auto-generated method stub
		return tRepo.findById(id);
	}

	public void deleteTrainee(Long id) {
		// TODO Auto-generated method stub
		tRepo.deleteById(id);;
	}



}
