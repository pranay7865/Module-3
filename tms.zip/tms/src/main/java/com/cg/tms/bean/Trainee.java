/**
 * 
 */
package com.cg.tms.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author anraipur
 *
 */
@Entity
public class Trainee {

	/**
	 * 
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String name;
	private String course;
	private String location;
	
	public Trainee() {
		// TODO Auto-generated constructor stub
	}

	public Trainee(Long id, String name, String course, String location) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
		this.location = location;
	}

	@Override
	public String toString() {
		return "Trainee [id=" + id + ", name=" + name + ", course=" + course + ", location=" + location + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
}
