package com.cg.tms;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.GetMapping;

import com.cg.tms.bean.Trainee;
import com.cg.tms.service.TraineeService;

@SpringBootApplication
public class TraineeManagementSystemApplication implements CommandLineRunner, ErrorController{

	
	@Autowired
	private TraineeService tService;
	
	private static final String PATH="/error";
	
	public static void main(String[] args) {
		SpringApplication.run(TraineeManagementSystemApplication.class, args);
	}

	@GetMapping(value=PATH)
	public String error() {
		
		return "please Enter Valid path";
	}
	
	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return PATH;
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		List<Trainee> list=new ArrayList<Trainee>();
		list=Arrays.asList(new Trainee(11l,"anuja","JEE Full Stack","Chennai MIPL"),
						new Trainee( 22l,"Pallavi","JEE Full Stack","Chennai MIPL"),
						new Trainee(33l,"raji","JEE Full Stack","Chennai MIPL"));
		
		tService.saveTrainees(list);
	}
}
