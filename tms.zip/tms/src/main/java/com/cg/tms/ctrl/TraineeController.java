/**
 * 
 */
package com.cg.tms.ctrl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.tms.bean.Trainee;
import com.cg.tms.service.TraineeService;

/**
 * @author anraipur
 *
 */
@Controller
public class TraineeController {

	@Autowired
	private TraineeService tService;
	
	
	@GetMapping("/trainee")
	public List<Trainee> listTrainees(){
		
		return tService.getAll();
	}
	
	
	@GetMapping("/trainee/{id}")
	public Optional<Trainee> getTrainee(@PathVariable Long id){
		
		return tService.getTrainee(id);
	}
	
	@PostMapping("/trainee")
	public Trainee addTrainee(@RequestBody Trainee trainee) {
		
		return tService.saveTrainee(trainee);
	}
	
	@DeleteMapping("/trainee/{id}")
	public void deleteTrainee(@PathVariable Long id) {
			
		tService.deleteTrainee(id);	
	}
}
