package com.cg.tms.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.tms.bean.Trainee;

@Repository
public interface TraineeRepository extends CrudRepository<Trainee,Long>{

}
