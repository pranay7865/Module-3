package com.cg.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cg.bean.Employee;
import com.cg.service.EmployeeServiceImpl;



/**
 * @author anraipur 
 * 
 * Implementation of EmployeeController
 *
 */

@RestController
public class EmployeeController {

	/**
	 * employeeServiceImpl is dependency of EmployeeController
	 */
	
	@Autowired
	private EmployeeServiceImpl employeeServiceImpl;

	/**
	 * Method Name: getEmployees()
	 * Return type: List<Employee>
	 * Parameters: NA
	 * Description: to get all the employee records
	 * Mapping: GET
	 * Path: /employees
	 *
	 */
	
	@GetMapping("/employees")
	public List<Employee> getEmployees() {
		return employeeServiceImpl.getAll();
	}
	

	/**
	 * Method Name: getEmployee()
	 * Return type: Optional<Employee>
	 * Parameters: long
	 * Description: search for the employee by id
	 * Mapping: GET
	 * Path: /getbyid/{id}
	 *
	 */
	
	@GetMapping(value = "/getbyid/{id}")
	public Optional<Employee> getEmployee(@PathVariable long id) {
		return employeeServiceImpl.getEmployee(id);
	}

	/**
	 * Method Name: addEmployee()
	 * Return type: ResponseEntity<Employee>
	 * Parameters: Employee
	 * Description: to add one employee record
	 * Mapping: POST
	 * Path: /addemployee
	 */
	
	@PostMapping("/addemployee")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee) {

		Employee e = employeeServiceImpl.addEmployee(employee);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(e.getEmpId());

		return ResponseEntity.created(location).build();

	}
	
	/**
	 * Method Name: saveEmployees()
	 * Return type: Iterable<Employee>
	 * Parameters: List<Employee>
	 * Description: to save multiple records
	 * Mapping: POST
	 * Path: /addemployees
	 */
	
	@PostMapping("/addemployees")
	public Iterable<Employee> saveEmployees(@RequestBody List<Employee> employees) {
	Iterable<Employee> q = employeeServiceImpl.saveEmployees(employees);

	return q;
	}
	
	/**
	 * Method Name: updateEmp()
	 * Return type: String
	 * Parameters: Employee, Long
	 * Description: to update one employee record
	 * Mapping: PUT
	 * Path: /updateemployee/{id}
	 */

	@PutMapping("/updateemployee/{id}")
	public String updateEmployee(@RequestBody Employee employee, @PathVariable long id) {
		employee.setEmpId(id);
		Employee e = employeeServiceImpl.updateEmp(employee);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(e.getEmpId());

		return "Record Updated "+ResponseEntity.created(location).build()+"\n"+e;

	}

	/**
	 * Method Name: deleteEmp()
	 * Return type: String
	 * Parameters: Long
	 * Description: to delete one employee record by id
	 * Mapping: DELETE
	 * /deleteemployee/{id}
	 *
	 */
	
	@DeleteMapping("/deleteemployee/{id}")
	public String deleteEmployee(@PathVariable long id) {
		employeeServiceImpl.deleteEmp(id);
		return "Deleted Successfully "+id;
	}
}
