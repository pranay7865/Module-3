/**
 * 
 */
package com.cg.country.service;

import java.util.Optional;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.country.bean.Country;
import com.cg.country.dao.CountryRepository;

/**
 * @author anraipur
 *
 */
@Service
public class CountryService {

	/**
	 * 
	 */
	@Autowired
	CountryRepository crep;
	
	public  Country addCountryInfo(Country country) {
		return crep.save(country);
	}
	
	public Optional<Country> findCountry(String id) {
		return crep.findById(Integer.parseInt(id));
	}

	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		List<Country> cList = new ArrayList<Country>();
				crep.findAll().forEach(cList::add);
		return cList;
	}

	public Country updateCountry(Country country, String id){
		
		return crep.save(country);

	}
}
