/**
 * 
 */
package com.cg.country.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.country.bean.Country;

/**
 * @author anraipur
 *
 */
@Repository
public interface CountryRepository extends CrudRepository<Country,Integer>{

	/**
	 * 
	 */
	
}
