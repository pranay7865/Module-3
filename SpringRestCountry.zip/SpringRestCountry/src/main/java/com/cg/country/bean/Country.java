/**
 * 
 */
package com.cg.country.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author anraipur
 *
 */
@Entity
public class Country {

	/**
	 * 
	 */
	@Id
	private Integer id;
	private String name;
	private String Capital;
	
	
	public Country(Integer id, String name, String capital) {
		super();
		this.id = id;
		this.name = name;
		Capital = capital;
	}


	@Override
	public String toString() {
		return "Country [id=" + id + ", name=" + name + ", Capital=" + Capital + "]";
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getCapital() {
		return Capital;
	}


	public void setCapital(String capital) {
		Capital = capital;
	}


	public Country() {
		// TODO Auto-generated constructor stub
	}

}
