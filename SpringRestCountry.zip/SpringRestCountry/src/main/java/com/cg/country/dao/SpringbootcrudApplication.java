package com.cg.country.dao;



import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.web.bind.annotation.GetMapping;


@SpringBootApplication
@ComponentScans(value = { @ComponentScan("com.cg.country.ctrl"), @ComponentScan("com.cg.country.service") })
@EntityScan(basePackages = "com.cg.country.bean")
public class SpringbootcrudApplication implements CommandLineRunner, ErrorController {

	private static final String PATH = "/error";

	public static void main(String[] args) {
		SpringApplication.run(SpringbootcrudApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		System.out.println("Spring Boot Application is Running Successfully!");
	}

	@GetMapping(value = PATH)
	public String error() {

		return "please Enter Valid path";
	}

	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return PATH;
	}
}