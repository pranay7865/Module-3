package com.boot.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.dao.EmployeeRepository;
import com.boot.entity.Employee;

@Service
public class EmployeeService {

	//employeeRepository is dependency of EmployeeService
	
	@Autowired
	private EmployeeRepository employeeRepository;

	
	  private List<Employee> listOfEmployee = new ArrayList<>(Arrays.asList(
			  new Employee("sai", "mukesh", "sai@gl.com"), 
			  new Employee("Samba", "Murthi","samba@gl.com"), 
			  new Employee("Android", "Sandeep", "sandeep@android.com"),
			  new Employee("Shiva", "Reddy", "shiva@gl.com"), 
			  new Employee("bablu","bambchik", "bablu@gl.com")));
	 
	public List<Employee> getAll() {
		List<Employee> list = new ArrayList<>();
		//list.add(new Employee("1", "Sharad", "sharad@gmail.com"));
		//employeeRepository.findAll().forEach(list::add);
		return listOfEmployee;
	}

	public Optional<Employee> getEmployee(String firstname) {
//		return listOfEmployee.stream().filter(s -> s.getFirstname().equals(firstname)).findFirst().get();
		return	Optional.ofNullable(listOfEmployee.stream().filter(s -> s.getId().equals(firstname)).findFirst().get());
		//return employeeRepository.findById(firstname);
	}

	public Employee addEmployee(Employee employee) {
//		listOfEmployee.add(employee);
		//return employeeRepository.save(employee);
		listOfEmployee.add(employee); // Added by abhishek
		return employee;
	}

	public Employee updateEmp(Employee employee, String firstname) {
		/*
		 * for (int i = 0; i < listOfEmployee.size(); i++) { if
		 * (listOfEmployee.get(i).getFirstname().equals(firstname)) {
		 * listOfEmployee.set(i, employee); } }
		 */
//		employeeRepository.saveByFirstname(employee);
		/**
		 * Added by abhishek testing start
		 */
		int index=-1;
		for (Employee employee2 : listOfEmployee) {
			if (null != employee2 && null != firstname && firstname.trim().toLowerCase().equals(employee2.getId().trim().toLowerCase())) {
				index = listOfEmployee.indexOf(employee2);
			}
		}
		if (index != -1) {
			listOfEmployee.remove(index);
			listOfEmployee.add(index, employee);
		}
		return employee;
		/**
		 * Added by abhishek testing end
		 */
		//return employeeRepository.save(employee);
		
	}

	public void deleteEmp(String firstname) {
//		for (int i = 0; i < listOfEmployee.size(); i++) {
//			if (listOfEmployee.get(i).getFirstname().equals(firstname))
//				listOfEmployee.remove(i);
//		}
		/**
		 * Added by abhishek for testing start
		 */
		ArrayList<Employee> tempList = new ArrayList<Employee>();
		tempList.addAll(listOfEmployee);
		for (Employee employee : listOfEmployee) {
			if (null != firstname && firstname.trim().toLowerCase().equalsIgnoreCase(employee.getId().toLowerCase())) {
				tempList.remove(employee);
				break;
			}
		}
			listOfEmployee.removeAll(listOfEmployee);
			listOfEmployee.addAll(tempList);
			/**
			 * Added by abhishek for testing end
			 */
		//employeeRepository.deleteById(firstname);
	}
}
