package com.boot;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.core.env.CommandLinePropertySource;

@SpringBootApplication
//@ComponentScan(basePackages = { "com.boot.controller", "com.boot.service", "com.boot.dao" })
@ComponentScans(value = { @ComponentScan("com.boot.controller"), @ComponentScan("com.boot.service") })
@EntityScan(basePackages = "com.boot.entity")
public class SpringbootcrudApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootcrudApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Spring Boot Application is Running Successfully!");
	}
}