package com.cg.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import org.springframework.stereotype.Component;

@Entity
@Table(name="customerrest")
@Component
public class Customer{
	
	
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "myseq")
	@SequenceGenerator(name = "myseq",sequenceName = "customerdataseq",initialValue =400,allocationSize = 1)
	private int cid;
	@Id
	private String mobile_no;
	private String name;
	@OneToOne(cascade = CascadeType.ALL) 
	@JoinColumn(name="walletId")
	private Wallet wallet;
	public Customer() {
		super();
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	

}
