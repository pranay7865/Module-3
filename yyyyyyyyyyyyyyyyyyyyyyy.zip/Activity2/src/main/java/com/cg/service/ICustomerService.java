package com.cg.service;

import java.math.BigDecimal;

import com.cg.beans.Customer;

public interface ICustomerService {
	public Customer createAccount(Customer customer);
	public double showBalance(String Mobile_no);
	public boolean fundTransfer (String sourceMobileNo,String targetMobileNo,BigDecimal amount);
	public boolean depositAmount(String Mobile_no,BigDecimal amount);
	public boolean withdrawAmount(String Mobile_no,BigDecimal amount);
	public String validateNum(String Mobile_no);
	

}
